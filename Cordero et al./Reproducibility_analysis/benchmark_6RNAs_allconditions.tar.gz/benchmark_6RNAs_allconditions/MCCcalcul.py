#!/usr/bin/env python2.7
from collections import defaultdict
import re
import os, subprocess, time
from os.path import isfile, join
import shutil # to move files from af folder to another
import math
import numpy as np

def openfile(Path):
    fileIn = open(Path, "r")
    lines = fileIn.readlines()
    fileIn.close()
    return lines

def GetListFile(PathFile, FileExtension):
    return [os.path.splitext(f)[0] for f in os.listdir(PathFile) if isfile(join(PathFile, f)) and os.path.splitext(f)[1] == '.' + FileExtension]

def GetListCentoidFile(PathFile):
    return [(os.path.splitext(f)[0],os.path.splitext(f)[1]) for f in os.listdir(PathFile) if isfile(join(PathFile, f)) ]

def parse_Ct_Structure(Path):
    lines = openfile(Path)
    return [int(re.sub( '\s+', ' ', elem ).strip().split(' ')[4])-1 for elem in lines[1:]]

def GetListCentoidFileMathiews(PathFile):
    return [(os.path.splitext(f)[0].strip().split(".")[0],os.path.splitext(f)[0].strip().split(".")[3]) for f in os.listdir(PathFile) if isfile(join(PathFile, f)) ]

def parse_Ct_Structurecentroids_mathiews(Path):
    lines = openfile(Path)
    return [int(re.sub( '\s+', ' ', elem ).strip().split(' ')[4])-1 for elem in lines]


def ListBasePairsFromStruct(Struct):  # return dic={structure:[liste de pairs de base ],....}
    lista = []
    stack = []
    for i in range(len(Struct)):  # sequence length
        if Struct[i] == '(':  # Opening base pair
            stack.append(i)
        elif Struct[i] == ')':  # Closing base pair
            k = stack.pop()
            lista.append((k, i))
    return lista
def PPV_Sensitivity_specificityinverse_MCC(Correct,Predicted,n):
    X=Correct
    Y= Predicted
    N= n*(n-1)/2.
    TP= (len(X)+len(Y)-len(set(X).symmetric_difference(set(Y)) ))/2
    FP= len(Y)-TP
    FN= len(X)-TP
    TN= N - len(Y)-len(X)+TP
    #print 'true positif', TP, "faux positifs", FP
    if (TP+FP)*(TP+FN)*(TN+FP)*(TN+FN)!=0:
    	#return PPV, Sensitivity, accuracy, MCC
    	return TP/float(TP+FP), TP/float(TP+FN),(TN+TP)/float(N),(TP*TN-FP*FN)/float(math.sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN)))
    else:
	return 0,0,0,0

def Accuracy_calculation(BPcorrect,BPpredicted, n):
	return round(math.sqrt(PPV_Sensitivity_specificityinverse_MCC(BPcorrect,BPpredicted,n)[0]*PPV_Sensitivity_specificityinverse_MCC(BPcorrect,BPpredicted,n)[1]),3)

def Check_pairing_status(list_paired_to):# a line in ct format with a number for the partner if paired and 0 if not
    status=[]
    ListPairs=[]
    for i,value in enumerate(list_paired_to):
        if value==-1:
            status.append('Un')
        else:
	    status.append('P')
            if i < value: # TO avoid the repetition of the tuple (x,y) : (y,x) and not to count for the tertiary constraints
            	ListPairs.append((i,value))
            
    return status,ListPairs

def Modelisation_RNAfold(path_Fasta, file, FileExtensionFasta,SHAPEfile ):    
	FastaPath=os.path.join(path_Fasta, file + '.' + FileExtensionFasta)
    	outputfile=str(file)+"SHapeoutput.txt"
    	command="RNAfold -p --MEA -d2 --noLP --noPS <" + FastaPath
	#print "jjjjjjjjj",SHAPEfile
    	if SHAPEfile!="":
		command+= " --shape "+ SHAPEfile 
    	command+= " > "+ outputfile
	#print command
   	os.system(command)
    	MfeStructure=openfile(outputfile)[2].strip().split(' ')[0]
    	Centroidstructure=openfile(outputfile)[4].strip().split(' ')[0]
    	MEAstructure=openfile(outputfile)[5].strip().split(' ')[0]
    	os.remove(outputfile)
    	os.remove(file+'_dp.ps')
    	return MfeStructure,Centroidstructure,MEAstructure

if __name__ == '__main__':

    States={}
    Shape={}
    structure={}
    ListPairs={}
    MEA_Pairs={}
    MEA_Pairs_SHAPE={}
    path='ct_files_withoutpseudoknots'
    path_probing='Probing_data'
    path_Fasta='fasta_files'
    FileExtension='ct'
    FileExtensionFasta='fa'
    PathCentroidsRPSP=['Multiprobing_c1','Multiprobing_c2','Multiprobing_c3']
    PathCentroidRsample='centroids_Rsample_2018'
    Rn=[]
    MCC=dict()
    Sens=defaultdict(lambda: defaultdict())
    PPV=defaultdict(lambda: defaultdict())
    Specifi=defaultdict(lambda: defaultdict())
    MCC=defaultdict(lambda: defaultdict())
    Centroid=defaultdict(lambda: defaultdict())
    ListaPairsfromcentroids=defaultdict(lambda: defaultdict())
    MCCSHAPE_Rsample=defaultdict(lambda: defaultdict())
    

    Ids=[filz for filz in GetListFile(path_Fasta, FileExtensionFasta)]
    #TODO: remove to calculate MFE_MEA
    '''
    ############################ MFE, MEA, Centroids with/without SHAPE
    print " MFE , MEA accuracies calculation :"
    print "RNA \t MFE \t MEA \t MFE_DMS \t MEA_DMS \t MFE_CMCT \t MEA_CMCT \t MFE_NMIA \t MEA_NMIA  "
    for fil in Ids:
	FastaPath = os.path.join(path_Fasta, fil + '.' + FileExtensionFasta) 
        rna = openfile(FastaPath)[1]
	ProbingfileDMS=os.path.join(path_probing, filz +'DMSShape.txt')
	ProbingfileNMIA=os.path.join(path_probing, filz +'NMIAShape.txt')
	ProbingfileCMCT=os.path.join(path_probing, filz +'CMCTShape.txt') 

    	MFE_Pairs=ListBasePairsFromStruct(Modelisation_RNAfold (path_Fasta, fil, FileExtensionFasta,"")[0])
        MEA_Pairs=ListBasePairsFromStruct(Modelisation_RNAfold (path_Fasta, fil, FileExtensionFasta,"")[2])
	### DMS
        MFE_Pairs_DMS=ListBasePairsFromStruct(Modelisation_RNAfold (path_Fasta, fil, FileExtensionFasta,ProbingfileDMS)[0])
        MEA_Pairs_DMS=ListBasePairsFromStruct(Modelisation_RNAfold (path_Fasta, fil, FileExtensionFasta,ProbingfileDMS)[2])
	### CMCT
        MFE_Pairs_CMCT=ListBasePairsFromStruct(Modelisation_RNAfold (path_Fasta, fil, FileExtensionFasta,ProbingfileCMCT)[0])
        MEA_Pairs_CMCT=ListBasePairsFromStruct(Modelisation_RNAfold (path_Fasta, fil, FileExtensionFasta,ProbingfileCMCT)[2])
	### NMIA
	MFE_Pairs_NMIA=ListBasePairsFromStruct(Modelisation_RNAfold (path_Fasta, fil, FileExtensionFasta,ProbingfileNMIA)[0])
        MEA_Pairs_NMIA=ListBasePairsFromStruct(Modelisation_RNAfold (path_Fasta, fil, FileExtensionFasta,ProbingfileNMIA)[2])
	### Get Base pairs from ct file
	BP= ListBasePairsFromStruct(openfile(FastaPath)[2])
	print fil, "\t", Accuracy_calculation(BP,MFE_Pairs,len(rna)),   "\t",Accuracy_calculation(BP,MEA_Pairs,len(rna)), "\t", Accuracy_calculation(BP,MFE_Pairs_DMS,len(rna)),   "\t",Accuracy_calculation(BP,MEA_Pairs_DMS,len(rna)), "\t",Accuracy_calculation(BP,MFE_Pairs_CMCT,len(rna)),   "\t",Accuracy_calculation(BP,MEA_Pairs_CMCT,len(rna)), "\t",Accuracy_calculation(BP,MFE_Pairs_NMIA,len(rna)),   "\t",Accuracy_calculation(BP,MEA_Pairs_NMIA,len(rna)) 
    '''
    ########################################################Validation IPANEMAP ############################"
    for PathCentroidsMultiprobing in  PathCentroidsRPSP:
            MCCSHAPE_RMPSP=defaultdict(lambda: defaultdict())
    	    print ' Evaluation scores calculation for ', PathCentroidsMultiprobing  
	    for fil in GetListCentoidFile(PathCentroidsMultiprobing): 
	        #print fil
		BPM=[]
		FastaPath = os.path.join(path_Fasta, fil[0] + '.' + FileExtensionFasta)       
		rna = openfile(FastaPath)[1]
                #print rna
		BPM=ListBasePairsFromStruct(openfile(os.path.join( PathCentroidsMultiprobing, (''.join([w for w in fil])).strip() ))[3])
		BP= ListBasePairsFromStruct(openfile(FastaPath)[2])

	    	MCCSHAPE_RMPSP[str(fil[0])][str(fil[1])]=(PPV_Sensitivity_specificityinverse_MCC(BP,BPM,len(rna))[0],PPV_Sensitivity_specificityinverse_MCC(BP,BPM,len(rna))[1],PPV_Sensitivity_specificityinverse_MCC(BP,BPM,len(rna))[2], PPV_Sensitivity_specificityinverse_MCC(BP,BPM,len(rna))[3])
	    for elem in Ids:	
		#print elem, [ round(MCCSHAPE_RMPSP[elem][centroi][3],4) for centroi in  MCCSHAPE_RMPSP[elem].keys()]
		MCC[PathCentroidsMultiprobing][elem]=[ (round(MCCSHAPE_RMPSP[elem][centroi][1],4), round(MCCSHAPE_RMPSP[elem][centroi][0],4), round(math.sqrt(round(MCCSHAPE_RMPSP[elem][centroi][0],4)*round(MCCSHAPE_RMPSP[elem][centroi][1],4)),3))  for centroi in  MCCSHAPE_RMPSP[elem].keys()]
    for elem in Ids:
            print '\n','>>>>>>>>>>>>>>>>>>>>>>>>>'+ elem +'<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
	    for Xpr in  PathCentroidsRPSP:
		print Xpr,"\t",
	    for Xpr in  PathCentroidsRPSP:
		print MCC[Xpr][elem][0][2],"\t",
    
